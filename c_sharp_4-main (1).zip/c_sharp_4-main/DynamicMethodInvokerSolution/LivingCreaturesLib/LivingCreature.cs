﻿using System;

namespace LivingCreaturesLib
{
    public abstract class LivingCreature : ILivingCreature
    {
        public double Speed { get; protected set; }
        protected abstract double MaxSpeed { get; }
        protected abstract double Step { get; }

        public virtual void Move()
        {
            Speed = Math.Min(Speed + Step, MaxSpeed);
        }

        public virtual void Stand()
        {
            Speed = Math.Max(Speed - Step, 0);
        }
    }
}