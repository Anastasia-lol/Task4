﻿using System;

namespace LivingCreaturesLib
{
    public class Dog : LivingCreature
    {
        protected override double MaxSpeed => 40;
        protected override double Step => 8;

        public event EventHandler Voice;

        public void MakeVoice()
        {
            Voice?.Invoke(this, EventArgs.Empty);
        }

        public string BarkTimes(int times)
        {
            return $"Dog barked {times} times.";
        }
    }
}