﻿using System;

namespace LivingCreaturesLib
{
    public class Panther : LivingCreature
    {
        protected override double MaxSpeed => 60;
        protected override double Step => 10;

        public event EventHandler Voice;

        public void MakeVoice()
        {
            Voice?.Invoke(this, EventArgs.Empty);
        }

        public string ClimbTree()
        {
            return "Panther climbed the tree!";
        }

        public string Jump(double height)
        {
            return $"Panther jumped {height} meters.";
        }
    }
}