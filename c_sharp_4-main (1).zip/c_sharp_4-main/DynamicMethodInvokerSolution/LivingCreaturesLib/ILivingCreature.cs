﻿namespace LivingCreaturesLib
{
    public interface ILivingCreature
    {
        double Speed { get; }
        void Move();
        void Stand();
    }
}