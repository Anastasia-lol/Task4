﻿namespace LivingCreaturesLib
{
    public class Turtle : LivingCreature
    {
        protected override double MaxSpeed => 5;
        protected override double Step => 1;

        public string HideInShell()
        {
            return "Turtle hid in its shell.";
        }
    }
}