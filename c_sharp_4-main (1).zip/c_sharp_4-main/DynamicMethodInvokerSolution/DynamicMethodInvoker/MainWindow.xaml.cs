﻿using System.Windows;
using DynamicMethodInvoker.ViewModels;

namespace DynamicMethodInvoker.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            DataContext = new MainViewModel();
        }
    }
}