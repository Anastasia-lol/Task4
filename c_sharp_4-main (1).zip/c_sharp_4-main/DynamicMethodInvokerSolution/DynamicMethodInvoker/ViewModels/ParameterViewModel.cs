﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace DynamicMethodInvoker.ViewModels
{
    public partial class ParameterViewModel : ObservableObject
    {
        [ObservableProperty]
        private string _name;

        [ObservableProperty]
        private string _typeName;

        [ObservableProperty]
        private string _valueString = "";

        [ObservableProperty]
        private bool _isBool;

        [ObservableProperty]
        private bool _boolValue;
    }
}