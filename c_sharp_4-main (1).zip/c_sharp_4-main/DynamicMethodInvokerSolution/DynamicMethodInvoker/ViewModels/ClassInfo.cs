﻿using System;

namespace DynamicMethodInvoker.ViewModels
{
    public class ClassInfo
    {
        public string Name { get; set; }
        public Type Type { get; set; }
    }
}