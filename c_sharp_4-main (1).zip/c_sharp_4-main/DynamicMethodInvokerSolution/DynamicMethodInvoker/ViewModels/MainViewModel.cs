﻿using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Reflection;
using System.Windows;

namespace DynamicMethodInvoker.ViewModels
{
    public partial class MainViewModel : ObservableObject
    {
        [ObservableProperty]
        private string _libraryPath = "";

        [ObservableProperty]
        private ObservableCollection<ClassInfo> _classes = new();

        [ObservableProperty]
        private ClassInfo _selectedClass;

        [ObservableProperty]
        private ObservableCollection<MethodInfo> _methods = new();

        [ObservableProperty]
        private MethodInfo _selectedMethod;

        [ObservableProperty]
        private ObservableCollection<ParameterViewModel> _parameters = new();

        [ObservableProperty]
        private string _speedInfo = "";

        private object _currentObject;
        private readonly List<(EventInfo ev, Delegate handler)> _eventSubscriptions = new();

        public IRelayCommand LoadCommand { get; }

        public MainViewModel()
        {
            LoadCommand = new RelayCommand(LoadLibrary);
        }

        private void LoadLibrary()
        {
            var dialog = new OpenFileDialog { Filter = "DLL files (*.dll)|*.dll" };
            if (dialog.ShowDialog() != true) return;

            LibraryPath = dialog.FileName;
            try
            {
                var asm = Assembly.LoadFrom(LibraryPath);
                var interfaceType = asm.GetType("LivingCreaturesLib.ILivingCreature");
                if (interfaceType == null)
                {
                    MessageBox.Show("ILivingCreature interface not found in assembly.");
                    return;
                }

                var types = asm.GetTypes()
                    .Where(t => t.IsClass && !t.IsAbstract && interfaceType.IsAssignableFrom(t));

                Classes.Clear();
                foreach (var t in types)
                    Classes.Add(new ClassInfo { Name = t.Name, Type = t });

                ClearSelection();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading library: {ex.Message}");
            }
        }

        partial void OnSelectedClassChanged(ClassInfo value)
        {
            if (value == null)
            {
                Methods.Clear();
                return;
            }

            UnsubscribeFromEvents();
            _currentObject = null;

            try
            {
                _currentObject = Activator.CreateInstance(value.Type);
                SubscribeToEvents();
                UpdateSpeedInfo();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error creating instance: {ex.Message}");
                return;
            }

            // Показываем все публичные методы экземпляра, кроме унаследованных от object
            var methodInfos = value.Type.GetMethods(BindingFlags.Public | BindingFlags.Instance)
                .Where(m => !m.IsSpecialName && m.DeclaringType != typeof(object))
                .ToList();

            Methods.Clear();
            foreach (var m in methodInfos)
                Methods.Add(m);

            SelectedMethod = null;
        }

        partial void OnSelectedMethodChanged(MethodInfo value)
        {
            Parameters.Clear();
            if (value == null) return;

            var paramInfos = value.GetParameters();
            foreach (var p in paramInfos)
            {
                Parameters.Add(new ParameterViewModel
                {
                    Name = p.Name,
                    TypeName = p.ParameterType.Name,
                    IsBool = p.ParameterType == typeof(bool)
                });
            }
        }

        private bool CanExecuteMethod() => SelectedMethod != null && _currentObject != null;

        [RelayCommand(CanExecute = nameof(CanExecuteMethod))]
        private void ExecuteMethod()
        {
            try
            {
                var paramInfos = SelectedMethod.GetParameters();
                var args = new object[paramInfos.Length];

                for (int i = 0; i < paramInfos.Length; i++)
                {
                    var vm = Parameters[i];
                    var targetType = paramInfos[i].ParameterType;

                    if (vm.IsBool)
                        args[i] = vm.BoolValue;
                    else
                        args[i] = Convert.ChangeType(vm.ValueString, targetType);
                }

                var result = SelectedMethod.Invoke(_currentObject, args);
                UpdateSpeedInfo();

                if (result != null)
                    MessageBox.Show($"Result: {result}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error: {ex.InnerException?.Message ?? ex.Message}");
            }
        }

        private void SubscribeToEvents()
        {
            if (_currentObject == null) return;
            var events = _currentObject.GetType().GetEvents();
            foreach (var ev in events)
            {
                if (ev.EventHandlerType == typeof(EventHandler))
                {
                    Delegate handler = new EventHandler((s, e) =>
                    {
                        MessageBox.Show($"Event '{ev.Name}' raised by {SelectedClass.Name}");
                    });
                    ev.AddEventHandler(_currentObject, handler);
                    _eventSubscriptions.Add((ev, handler));
                }
            }
        }

        private void UnsubscribeFromEvents()
        {
            if (_currentObject == null) return;
            foreach (var sub in _eventSubscriptions)
                sub.ev.RemoveEventHandler(_currentObject, sub.handler);
            _eventSubscriptions.Clear();
        }

        private void UpdateSpeedInfo()
        {
            if (_currentObject == null)
            {
                SpeedInfo = "";
                return;
            }

            var prop = _currentObject.GetType().GetProperty("Speed");
            if (prop != null)
            {
                var speed = prop.GetValue(_currentObject);
                SpeedInfo = $"Current speed: {speed}";
            }
        }

        private void ClearSelection()
        {
            SelectedClass = null;
            SelectedMethod = null;
            _currentObject = null;
            _eventSubscriptions.Clear();
            SpeedInfo = "";
        }
    }
}