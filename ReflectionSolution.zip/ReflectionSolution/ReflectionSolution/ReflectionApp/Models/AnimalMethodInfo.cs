﻿using System;
using System.Reflection;

namespace ReflectionApp.Models
{
    public class AnimalMethodInfo
    {
        public MethodInfo Method { get; set; }
        public string Name => Method.Name;
        public ParameterInfo[] Parameters => Method.GetParameters();
    }
}