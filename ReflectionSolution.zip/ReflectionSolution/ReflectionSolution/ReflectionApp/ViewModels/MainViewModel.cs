﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Windows.Input;
using Microsoft.Win32;
using ReflectionApp.Models;

namespace ReflectionApp.ViewModels
{
    public class MainViewModel : INotifyPropertyChanged
    {
        private string _assemblyPath = string.Empty;
        private Assembly? _loadedAssembly;
        private ObservableCollection<Type> _animalTypes = new ObservableCollection<Type>();
        private Type? _selectedType;
        private ObservableCollection<AnimalMethodInfo> _methods = new ObservableCollection<AnimalMethodInfo>();
        private AnimalMethodInfo? _selectedMethod;
        private ObservableCollection<ParameterViewModel> _parameters = new ObservableCollection<ParameterViewModel>();
        private string _executionResult = string.Empty;

        public string AssemblyPath
        {
            get => _assemblyPath;
            set { _assemblyPath = value; OnPropertyChanged(); }
        }

        public ObservableCollection<Type> AnimalTypes
        {
            get => _animalTypes;
            set { _animalTypes = value; OnPropertyChanged(); }
        }

        public Type? SelectedType
        {
            get => _selectedType;
            set
            {
                _selectedType = value;
                OnPropertyChanged();
                LoadMethods();
            }
        }

        public ObservableCollection<AnimalMethodInfo> Methods
        {
            get => _methods;
            set { _methods = value; OnPropertyChanged(); }
        }

        public AnimalMethodInfo? SelectedMethod
        {
            get => _selectedMethod;
            set
            {
                _selectedMethod = value;
                OnPropertyChanged();
                LoadParameters();
            }
        }

        public ObservableCollection<ParameterViewModel> Parameters
        {
            get => _parameters;
            set { _parameters = value; OnPropertyChanged(); }
        }

        public string ExecutionResult
        {
            get => _executionResult;
            set { _executionResult = value; OnPropertyChanged(); }
        }

        public ICommand BrowseCommand { get; }
        public ICommand LoadAssemblyCommand { get; }
        public ICommand ExecuteMethodCommand { get; }

        public MainViewModel()
        {
            BrowseCommand = new RelayCommand(_ => BrowseAssembly());
            LoadAssemblyCommand = new RelayCommand(_ => LoadAssembly(), _ => !string.IsNullOrEmpty(AssemblyPath));
            ExecuteMethodCommand = new RelayCommand(_ => ExecuteMethod(), _ => SelectedType != null && SelectedMethod != null);
        }

        private void BrowseAssembly()
        {
            var dialog = new OpenFileDialog
            {
                Filter = "DLL files (*.dll)|*.dll|All files (*.*)|*.*",
                Title = "Выберите сборку с классами животных"
            };
            if (dialog.ShowDialog() == true)
            {
                AssemblyPath = dialog.FileName;
            }
        }

        private void LoadAssembly()
        {
            try
            {
                _loadedAssembly = Assembly.LoadFrom(AssemblyPath);
                // Ищем все публичные типы, реализующие интерфейс IAnimal (или наследующие LivingBeing)
                var animalInterface = _loadedAssembly.GetType("AnimalsLibrary.IAnimal");
                if (animalInterface == null)
                {
                    var livingBeingType = _loadedAssembly.GetType("AnimalsLibrary.LivingBeing");
                    if (livingBeingType != null)
                    {
                        AnimalTypes.Clear();
                        foreach (var type in _loadedAssembly.GetExportedTypes())
                        {
                            if (livingBeingType.IsAssignableFrom(type) && !type.IsAbstract)
                                AnimalTypes.Add(type);
                        }
                    }
                    else
                        ExecutionResult = "Интерфейс IAnimal или базовый класс LivingBeing не найден в сборке.";
                }
                else
                {
                    AnimalTypes.Clear();
                    foreach (var type in _loadedAssembly.GetExportedTypes())
                    {
                        if (animalInterface.IsAssignableFrom(type) && !type.IsAbstract)
                            AnimalTypes.Add(type);
                    }
                }
                ExecutionResult = $"Загружено типов: {AnimalTypes.Count}";
            }
            catch (Exception ex)
            {
                ExecutionResult = $"Ошибка загрузки: {ex.Message}";
            }
        }

        private void LoadMethods()
        {
            Methods.Clear();
            if (SelectedType == null) return;
            // Получаем все публичные методы (кроме свойств и методов базовых объектов)
            var allMethods = SelectedType.GetMethods(BindingFlags.Public | BindingFlags.Instance | BindingFlags.DeclaredOnly);
            foreach (var method in allMethods)
            {
                if (!method.IsSpecialName)
                    Methods.Add(new AnimalMethodInfo { Method = method });
            }
        }

        private void LoadParameters()
        {
            Parameters.Clear();
            if (SelectedMethod == null) return;
            foreach (var param in SelectedMethod.Parameters)
            {
                Parameters.Add(new ParameterViewModel
                {
                    ParameterName = param.Name ?? "param",
                    ParameterType = param.ParameterType,
                    Value = GetDefaultValue(param.ParameterType)
                });
            }
        }

        private object? GetDefaultValue(Type type)
        {
            if (type == typeof(string)) return "";
            if (type == typeof(int)) return 0;
            if (type == typeof(double)) return 0.0;
            if (type == typeof(bool)) return false;
            if (type.IsValueType) return Activator.CreateInstance(type);
            return null;
        }

        private void ExecuteMethod()
        {
            if (SelectedType == null || SelectedMethod == null) return;
            try
            {
                object? instance = Activator.CreateInstance(SelectedType);
                if (instance == null)
                {
                    ExecutionResult = "Не удалось создать экземпляр класса.";
                    return;
                }

                var parameters = SelectedMethod.Parameters;
                object?[] arguments = new object?[parameters.Length];
                for (int i = 0; i < parameters.Length; i++)
                {
                    var paramVM = Parameters[i];
                    arguments[i] = ConvertParameter(paramVM.Value, parameters[i].ParameterType);
                }

                object? result = SelectedMethod.Method.Invoke(instance, arguments);
                ExecutionResult = $"Метод '{SelectedMethod.Name}' выполнен.\n";
                if (result != null)
                    ExecutionResult += $"Результат: {result}\n";

                var infoMethod = instance.GetType().GetMethod("GetInfo");
                if (infoMethod != null)
                {
                    var info = infoMethod.Invoke(instance, null);
                    ExecutionResult += $"Состояние объекта: {info}";
                }
            }
            catch (Exception ex)
            {
                ExecutionResult = $"Ошибка выполнения: {ex.InnerException?.Message ?? ex.Message}";
            }
        }

        private object? ConvertParameter(object? value, Type targetType)
        {
            if (value == null) return null;
            if (targetType == typeof(string)) return value.ToString();
            if (targetType == typeof(int)) return Convert.ToInt32(value);
            if (targetType == typeof(double)) return Convert.ToDouble(value);
            if (targetType == typeof(bool)) return Convert.ToBoolean(value);
            return value;
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }

    public class ParameterViewModel : INotifyPropertyChanged
    {
        private string _parameterName = string.Empty;
        private Type _parameterType = typeof(object);
        private object? _value;

        public string ParameterName
        {
            get => _parameterName;
            set { _parameterName = value; OnPropertyChanged(); }
        }

        public Type ParameterType
        {
            get => _parameterType;
            set { _parameterType = value; OnPropertyChanged(); OnPropertyChanged(nameof(DisplayType)); }
        }

        public string DisplayType => ParameterType.Name;

        public object? Value
        {
            get => _value;
            set { _value = value; OnPropertyChanged(); }
        }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null) =>
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
    }
}