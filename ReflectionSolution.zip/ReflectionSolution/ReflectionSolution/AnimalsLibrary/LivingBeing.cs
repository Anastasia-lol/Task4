﻿using System;

namespace AnimalsLibrary
{
    public abstract class LivingBeing : IAnimal
    {
        private double _speed;
        public double Speed
        {
            get => _speed;
            protected set
            {
                _speed = Math.Clamp(value, MinSpeed, MaxSpeed);
            }
        }

        public abstract double MaxSpeed { get; }
        public virtual double MinSpeed => 0;
        public double Step { get; protected set; }

        // Конструктор с параметром
        protected LivingBeing(double step)
        {
            Step = step;
            Speed = 0;
        }

        // Конструктор по умолчанию (для рефлексии)
        protected LivingBeing() : this(1) { }

        public abstract void Move();
        public abstract void Stand();
        public abstract void RaiseVoice();

        public virtual void SetSpeed(double speed) { Speed = speed; }

        public abstract string GetInfo();
        public abstract string Name { get; }
    }
}