﻿namespace AnimalsLibrary
{
    public class Dog : LivingBeing
    {
        public override double MaxSpeed => 50.0;
        public override string Name => "Собака";

        public Dog() : base(5.0) { }

        public override void Move() => Speed += Step;
        public override void Stand() => Speed -= Step;
        public override void RaiseVoice() => System.Console.WriteLine("Собака лает: Гав-гав-гав!");

        public override string GetInfo() => $"{Name}, скорость: {Speed:F1} ед./с";
    }
}