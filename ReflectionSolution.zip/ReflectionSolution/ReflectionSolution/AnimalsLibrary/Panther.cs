﻿namespace AnimalsLibrary
{
    public class Panther : LivingBeing
    {
        public override double MaxSpeed => 100.0;
        public override string Name => "Пантера";

        public Panther() : base(10.0) { }

        public override void Move() => Speed += Step;
        public override void Stand() => Speed -= Step;
        public override void RaiseVoice() => System.Console.WriteLine("Пантера рычит: Р-Р-Р-Р!");

        public void ClimbTree() => System.Console.WriteLine("Пантера залезла на дерево!");

        public override string GetInfo() => $"{Name}, скорость: {Speed:F1} ед./с";
    }
}