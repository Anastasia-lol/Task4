﻿namespace AnimalsLibrary
{
    public interface IAnimal
    {
        string Name { get; }
        void Move();
        void Stand();
        void RaiseVoice();
        string GetInfo();
        void SetSpeed(double speed);
    }
}