﻿namespace AnimalsLibrary
{
    public class Turtle : LivingBeing
    {
        public override double MaxSpeed => 5.0;
        public override string Name => "Черепаха";

        public Turtle() : base(0.5) { }

        public override void Move() => Speed += Step;
        public override void Stand() => Speed -= Step;
        public override void RaiseVoice() => System.Console.WriteLine("Черепаха молчит...");

        public override string GetInfo() => $"{Name}, скорость: {Speed:F1} ед./с (медленно)";
    }
}